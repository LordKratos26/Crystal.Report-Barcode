﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        DataTable dt;
        ReportDocument crp = new ReportDocument();
        int i = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void addbarcode_Click(object sender, EventArgs e)
        {
            while (i < numericUpDown1.Value)
            {
                dt.Rows.Add(textBox1.Text, textBox2.Text, textBox3.Text);
                crp.Load(comboBox1.GetItemText(comboBox1.SelectedValue));
                crp.SetDataSource(dt);
                crystalReportViewer1.ReportSource = crp;
                i++;
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Cryreport> Crystalreportlist = new List<Cryreport> {
                new Cryreport() { Name = "8/2 olan olcu" , Link = @"c:\Users\HELP\Documents\Visual Studio 2015\Projects\WindowsFormsApplication3\WindowsFormsApplication3\CrystalReport1.rpt" },
                new Cryreport() { Name = "Tek olan", Link = @"c:\Users\HELP\Documents\Visual Studio 2015\Projects\WindowsFormsApplication3\WindowsFormsApplication3\CrystalReport2.rpt" }

            };

            comboBox1.DataSource = Crystalreportlist;
            comboBox1.DisplayMember = "Name";
            comboBox1.ValueMember = "Link";
            
            
            dt = new DataTable();
            dt.TableName = "Info";
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Product name", typeof(string));
        }
  
    }
}