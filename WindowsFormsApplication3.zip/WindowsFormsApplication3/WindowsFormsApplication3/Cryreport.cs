﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication3
{
    public class Cryreport
    {

        public string Name { get; set; }
        public string Link { get; set; }

    }
}
